npx express-generator
npm i nodemon

nodemon to run

npm install mysql
npm install --save multer